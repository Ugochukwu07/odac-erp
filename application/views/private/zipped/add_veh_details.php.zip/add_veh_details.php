<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <!--<h3 class="box-title"></h3>-->
                </div>
                <!-- /.box-header -->
<div class="box-body">
    <?php echo form_open_multipart( adminurl('Add_veh_details/savedata' )); ?>
    <?php echo form_hidden('id', $id);?> 
    <div class="row">
        <div class="col-md-6">
            <div class="row mg_top_2">
                <div class="col-lg-12">

                                <div class="row">
                                <div class="form-group col-lg-6"> 
                                    <?php echo form_label('Vehicle Number', 'vehicle_con_id');?>
                                    <?php echo form_dropdown(array('name'=>'vehicle_con_id','required'=>'required','class'=>'form-control'),$vehiclelist,set_value('vehicle_con_id',$vehicle_con_id));?>
                                </div>
                                </div>


                                <div class="row">
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('White Permit From', 'white_permit_from');?>
                                    <?php echo form_input(array('name'=>'white_permit_from','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter white permit from date','autocomplete'=>'off','onchange'=>"filldate(this.value,'white_permit_till')",'data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('white_permit_from',$white_permit_from) );?>
                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('White Permit To', 'white_permit_till');?>
                                    <?php echo form_input(array('name'=>'white_permit_till','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter white permit till date','autocomplete'=>'off','id'=>'white_permit_till','data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('white_permit_till',$white_permit_till) );?>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Permit From', 'permit_from');?>
                                    <?php echo form_input(array('name'=>'permit_from','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter permit from date','autocomplete'=>'off','onchange'=>"filldate(this.value,'permit_till')",'data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('permit_from',$permit_from) );?>
                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Permit To', 'permit_till');?>
                                    <?php echo form_input(array('name'=>'permit_till','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Ente permrit till date','autocomplete'=>'off','id'=>'permit_till','data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('permit_till',$permit_till) );?>
                                </div>
                                </div>
                                
                                
                                <div class="row">
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Tax Valid From', 'tax_from');?>
                                    <?php echo form_input(array('name'=>'tax_from','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter tax from date','autocomplete'=>'off','onchange'=>"filldate(this.value,'tax_till')",'data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('tax_from',$tax_from ) );?>
                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Tax Valid To', 'tax_till');?>
                                    <?php echo form_input(array('name'=>'tax_till','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter tax till date','autocomplete'=>'off','id'=>'tax_till','data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('tax_till',$tax_till) );?>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Fitness From', 'fitness_from');?>
                                    <?php echo form_input(array('name'=>'fitness_from','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter fitness from date','autocomplete'=>'off','onchange'=>"filldate(this.value,'fitness_till')",'data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('fitness_from',$fitness_from) );?>
                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Fitness To', 'fitness_till');?>
                                    <?php echo form_input(array('name'=>'fitness_till','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter fitness till date','autocomplete'=>'off','id'=>'fitness_till','data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('fitness_till',$fitness_till) );?>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Insurence From', 'insurence_from');?>
                                    <?php echo form_input(array('name'=>'insurence_from','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter insurence from date','autocomplete'=>'off','onchange'=>"filldate(this.value,'insurence_till')",'data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('insurence_from',$insurence_from) );?>
                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Insurence To', 'insurence_till');?>
                                    <?php echo form_input(array('name'=>'insurence_till','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter insurence till date','autocomplete'=>'off','id'=>'insurence_till','data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('white_permit_till',$insurence_till) );?>
                                </div>
                                </div>
                                
                                <div class="row">
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Pollution From', 'polution_from');?>
                                    <?php echo form_input(array('name'=>'polution_from','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter pollution from date','autocomplete'=>'off','onchange'=>"filldate(this.value,'polution_till')",'data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('polution_from',$polution_from) );?>
                                </div>
                                <div class="form-group col-lg-6">
                                    <?php echo form_label('Pollution To', 'polution_till');?>
                                    <?php echo form_input(array('name'=>'polution_till','required'=>'required','class'=>'form-control datepicker','placeholder'=>'Enter pollution till date','autocomplete'=>'off','id'=>'polution_till','data-date-format'=>'yyyy-mm-dd','data-date'=>''), set_value('polution_till',$polution_till) );?>
                                </div>
                                </div>
                                
                                <div class="row" style="margin-top:10px">
                                    <div class="col-md-3" >
                                        <?php echo form_submit('mysubmit', ( !empty($id) ? 'Update' : 'Submit' ), array('class'=>'btn btn-primary') );  ?>
                                    </div>
<div class="col-md-3 pull-right">
<?php if( VIEW ==='yes'){ 
echo anchor( adminurl('vehicle_d_list'),'View',array('class'=>'btn btn-primary fa fa-sign-out'));}?>
</div>
</div>
                                                <?php echo form_close(); ?>
                                                <div class="spacer-10"></div>
                                                <!-- /.box-body -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!----------------- Main content end ------------------------->
                            </div>
                        </div>
                        <!--------- /.content-wrapper --------->
                    </div>  
                </section></div></div>
                <script>
                    function filldate( dtval, id ){
                        $('#'+id).val( dtval );
                    }
                    
    $(function () {
            $('.datepicker').datepicker({
            format: 'dd/mm/yyyy'
            });
    });
                </script>